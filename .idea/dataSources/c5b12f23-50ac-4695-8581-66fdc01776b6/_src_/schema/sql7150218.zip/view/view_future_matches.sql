CREATE VIEW `view_future_matches` AS
  SELECT
    `sql7150218`.`Match`.`date`  AS `date`,
    `sql7150218`.`League`.`name` AS `league`,
    `sql7150218`.`Team`.`name`   AS `away_team`,
    `Team_1`.`name`              AS `home_team`
  FROM (((`sql7150218`.`Match`
    JOIN `sql7150218`.`Team` ON ((`sql7150218`.`Match`.`awayTeam_id` = `sql7150218`.`Team`.`id`))) JOIN
    `sql7150218`.`Team` `Team_1` ON ((`sql7150218`.`Match`.`homeTeam_id` = `Team_1`.`id`))) JOIN `sql7150218`.`League`
      ON (((`sql7150218`.`Match`.`league_id` = `sql7150218`.`League`.`id`) AND
           (`sql7150218`.`Team`.`league_id` = `sql7150218`.`League`.`id`) AND
           (`Team_1`.`league_id` = `sql7150218`.`League`.`id`))))
  WHERE (`sql7150218`.`Match`.`date` > cast((now() + INTERVAL -(8) HOUR) AS DATE))
  ORDER BY `sql7150218`.`Match`.`date`